# bible annotations with django
