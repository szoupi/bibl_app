// delete object dialog
function fConfirm() {
    if (confirm("Should I delete it?") == false) {
        event.preventDefault()
    }
}