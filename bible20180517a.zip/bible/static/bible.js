// delete object dialog
function fConfirm() {
	if (confirm('Should I delete it?') == false) {
		event.preventDefault()
	}
}


var csrftoken = Cookies.get('csrftoken');
var json_data = {}
